export default function UpdateTest() {
  return <h2>UpdateTest</h2>;
}
