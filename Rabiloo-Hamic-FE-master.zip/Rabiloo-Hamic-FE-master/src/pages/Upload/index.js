function Upload() {
    return(
        <div>
            <h2>Upload Page</h2>
            <ul className="listCourses"></ul>
        </div>
    );
}

export default Upload;
