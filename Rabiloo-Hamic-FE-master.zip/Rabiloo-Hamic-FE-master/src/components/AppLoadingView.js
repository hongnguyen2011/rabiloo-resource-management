import { CircularProgress } from "@mui/material";

export function AppLoadingView() {
  return <CircularProgress style={{ marginLeft: "46%", marginTop: 60 }} />;
}
